<?php
	
	include 'ConfigurationUserManagement.php';
 
	$story = $_GET["story"];

	ConsultImagesStory($story);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	
	 //-------------------------------------------------------------
     //  ConsultImagesStory
     //-------------------------------------------------------------
     function ConsultImagesStory($story_par)
     {
		$query_consult = "SELECT * FROM bookimages WHERE story = $story_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::ConsultImagesStory::Select images for story $story_par failed");

		$output_list = "";
		while ($row_image = mysqli_fetch_object($result_consult))
		{
			$id_image = $row_image->id;
			$story_image = $row_image->story;
			$name_image = $row_image->name;
			$category_image = $row_image->category;

			$entry_image = $id_image . $GLOBALS['PARAM_SEPARATOR'] . $story_image . $GLOBALS['PARAM_SEPARATOR'] . $name_image . $GLOBALS['PARAM_SEPARATOR'] . $category_image;
			$output_list = $output_list . $GLOBALS['LINE_SEPARATOR'] . $entry_image;
		}
		
		print "true" . $GLOBALS['BLOCK_SEPARATOR'] . $output_list;
		
		mysqli_free_result($result_consult);
    }	
	
?>
