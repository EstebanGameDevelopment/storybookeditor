<?php
	
	include 'ConfigurationUserManagement.php';
 
	$story = $_GET["story"];

	ConsultSoundsStory($story);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	
	 //-------------------------------------------------------------
     //  ConsultSoundsStory
     //-------------------------------------------------------------
     function ConsultSoundsStory($story_par)
     {
		$query_consult = "SELECT * FROM booksounds WHERE story = $story_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::ConsultSoundsStory::Select images for story $story_par failed");

		$output_list = "";
		while ($row_sound = mysqli_fetch_object($result_consult))
		{
			$id_sound = $row_sound->id;
			$story_sound = $row_sound->story;
			$name_sound = $row_sound->name;
			$category_sound = $row_sound->category;
			$extension_sound = $row_sound->extension;

			$entry_sound = $id_sound . $GLOBALS['PARAM_SEPARATOR'] . $story_sound . $GLOBALS['PARAM_SEPARATOR'] . $name_sound . $GLOBALS['PARAM_SEPARATOR'] . $category_sound . $GLOBALS['PARAM_SEPARATOR'] . $extension_sound;
			$output_list = $output_list . $GLOBALS['LINE_SEPARATOR'] . $entry_sound;
		}
		
		print "true" . $GLOBALS['BLOCK_SEPARATOR'] . $output_list;
		
		mysqli_free_result($result_consult);
    }	
	
?>
