<?php
	
	include 'ConfigurationUserManagement.php';
	
	$id = $_GET["id"];
	
	DisplaySinglePromptDecompressed($id);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  DisplaySinglePromptDecompressed
     //-------------------------------------------------------------
     function DisplaySinglePromptDecompressed($id_par)
     {
		$query_consult = "SELECT * FROM sessionprompts WHERE id = $id_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::DisplaySinglePromptDecompressed::Select prompts for ID $id_par failed");

		if ($row_prompt = mysqli_fetch_object($result_consult))
		{
			$data = $row_prompt->data;
			
			echo "<pre>" . htmlspecialchars(gzdecode($data)) . "</pre>";
		}
		else
		{
			echo "NO DATA";
		}
    }

?>
