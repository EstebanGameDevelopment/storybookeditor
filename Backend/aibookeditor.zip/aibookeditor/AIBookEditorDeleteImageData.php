<?php
	
	include 'ConfigurationUserManagement.php';

	$data = $_POST["data"];

	$item_image = explode(';', $data);
	$number_images = count($item_image);

	$i = 0;
	for ($i = 0; $i < $number_images; $i++)			 
	{
		DeleteImageData(intval($item_image[$i]));
	}
	
	print "true";

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  DeleteImageData
     //-------------------------------------------------------------
     function DeleteImageData($id_par)
     {
		$query_delete_sound = "DELETE FROM bookimages WHERE id = $id_par";
		mysqli_query($GLOBALS['LINK_DATABASE'], $query_delete_sound) or die("Query Error::DeleteImageData::Failed to delete image $id_par");
		
		if (mysqli_affected_rows($GLOBALS['LINK_DATABASE']) == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
    }

?>
