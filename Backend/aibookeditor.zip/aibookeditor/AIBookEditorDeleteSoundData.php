<?php
	
	include 'ConfigurationUserManagement.php';

	$data = $_POST["data"];

	$item_sound = explode(';', $data);
	$number_sounds = count($item_sound);

	$i = 0;
	for ($i = 0; $i < $number_sounds; $i++)			 
	{
		DeleteSoundData(intval($item_sound[$i]));
	}

	print "true";

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  DeleteSoundData
     //-------------------------------------------------------------
     function DeleteSoundData($id_par)
     {
		$query_delete_sound = "DELETE FROM booksounds WHERE id = $id_par";
		mysqli_query($GLOBALS['LINK_DATABASE'], $query_delete_sound) or die("Query Error::DeleteSoundData::Failed to delete sound $id_par");
		
		if (mysqli_affected_rows($GLOBALS['LINK_DATABASE']) == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
    }

?>
