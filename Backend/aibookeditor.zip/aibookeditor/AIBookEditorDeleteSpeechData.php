<?php
	
	include 'ConfigurationUserManagement.php';

	$story = $_GET["story"];
	$chapter = $_GET["chapter"];
	$page = $_GET["page"];

	DeleteSpeechData($story, $chapter, $page);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  DeleteSpeechData
     //-------------------------------------------------------------
     function DeleteSpeechData($story_par, $chapter_par, $page_par)
     {
		$query_delete_speech = "";
		
		if ($story_par != -1) $query_delete_speech = "DELETE FROM bookspeech WHERE story = $story_par";
		if (($story_par != -1) && ($chapter_par != -1)) $query_delete_speech = "DELETE FROM bookspeech WHERE story = $story_par AND chapter = $chapter_par";
		if (($story_par != -1) && ($chapter_par != -1) && ($page_par != -1)) $query_delete_speech = "DELETE FROM bookspeech WHERE story = $story_par AND chapter = $chapter_par AND page = $page_par";
		
		if (strlen($query_delete_speech) > 1)
		{
			mysqli_query($GLOBALS['LINK_DATABASE'],$query_delete_speech) or die("Query Error::DeleteSpeechData::Failed to delete speech $story_par, $chapter_par, $page_par");
			
			if (mysqli_affected_rows($GLOBALS['LINK_DATABASE']) == 1)
			{
				print "true";
			}
			else
			{
				print "false";
			}
		}
    }

?>
