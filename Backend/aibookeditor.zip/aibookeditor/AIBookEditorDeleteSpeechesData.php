<?php
	
	include 'ConfigurationUserManagement.php';

	$data = $_GET["data"];

	DeleteSpeechesData($data);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
     //  DeleteSpeechID
     //-------------------------------------------------------------
     function DeleteSpeechID($id_par)
     {
		$query_delete_speech = "DELETE FROM bookspeech WHERE id = $id_par";
		mysqli_query($GLOBALS['LINK_DATABASE'],$query_delete_speech) or die("Query Error::DeleteSpeechID::Failed to delete speech $id_par");
		
		if (mysqli_affected_rows($GLOBALS['LINK_DATABASE']) == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
     //-------------------------------------------------------------
     //  DeleteSpeechesData
     //-------------------------------------------------------------
     function DeleteSpeechesData($data_par)
     {
		 $speech_ids = explode(',', $data_par);
		 $total_ids = count($speech_ids);
		 
		 $i = 0;
		 for ($i = 0; $i < $total_ids; $i++)			 
		 {
			DeleteSpeechID($speech_ids[$i]);
		 }
		 
		 print "true";
    }

?>
