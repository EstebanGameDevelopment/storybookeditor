<?php
	
	include 'ConfigurationUserManagement.php';
	
	$session = $_GET["session"];
	
	DisplayPromptData($session);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  DisplayPromptData
     //-------------------------------------------------------------
     function DisplayPromptData($session_par)
     {
		$query_consult = "SELECT * FROM sessionprompts WHERE session = '$session_par' ORDER BY id ASC";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::DisplayPromptData::Select prompts for $session_par failed");

		echo "<H1>$session_par: Prompt History</H1><p>";

		echo "<table border='1'><tr><th>MODE</th><th>COMMAND</th><th>LLM</th><th>PROMPT</th></tr>";
		
		while ($row_prompt = mysqli_fetch_object($result_consult))
		{
			$id = $row_prompt->id;
			$mode = $row_prompt->mode;
			$command = $row_prompt->command;
			$llm = $row_prompt->llm;

			$modedisplay = "";
			$reponsedisplay = "";
			if ($mode == 1)
			{
				$modedisplay = "AI";
				$reponsedisplay = "AI RESPONSE";
			}
			else
			{
				$modedisplay = "HUMAN";
				$reponsedisplay = "FULL PROMPT";
			}				
			
			echo "<tr>";
			echo "<td>" . $modedisplay . "</td>";
			echo "<td>" . $command . "</td>";
			echo "<td>" . $llm . "</td>";			
			echo "<td><a href=\"http://localhost:8080/aibookeditor/AIBookEditorDecompressSinglePrompt.php?id=".$id."\">".$reponsedisplay."</a></td>";
			echo "</tr>";
		}
		
		echo "</table>";
    }

?>
