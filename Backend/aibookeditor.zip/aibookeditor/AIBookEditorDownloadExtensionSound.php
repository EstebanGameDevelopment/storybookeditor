<?php
	
	include 'ConfigurationUserManagement.php';
 
	$id = $_GET["id"];

	DownloadExtensionSound($id);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	
	 //-------------------------------------------------------------
     //  DownloadExtensionSound
     //-------------------------------------------------------------
     function DownloadExtensionSound($id_par)
     {
		$query_consult = "SELECT * FROM booksounds WHERE id = $id_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::DownloadSoundData::Download image $id_par failed");

		if ($row_data = mysqli_fetch_object($result_consult))
		{
			$extension = $row_data->extension;

			print  "true" . $GLOBALS['PARAM_SEPARATOR'] . $extension;
		}
		else
		{
			print "false";
		}
		
		mysqli_free_result($result_consult);
    }	
	
?>
