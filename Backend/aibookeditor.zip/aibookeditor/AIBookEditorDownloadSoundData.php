<?php
	
	include 'ConfigurationUserManagement.php';
 
	$id = $_GET["id"];
	$direct = $_GET["direct"];

	DownloadSoundData($id, $direct == 1);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	
	 //-------------------------------------------------------------
     //  DownloadSoundData
     //-------------------------------------------------------------
     function DownloadSoundData($id_par, $direct_par)
     {
		$query_consult = "SELECT * FROM booksounds WHERE id = $id_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::DownloadSoundData::Download image $id_par failed");

		if ($row_data = mysqli_fetch_object($result_consult))
		{
			$name = $row_data->name;
			$extension = $row_data->extension;
			$size = $row_data->size;
			$data = $row_data->data;
	
			if ($direct_par)
			{
				// Set headers to force download
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="' . basename($name) . $extension . '"');
				header('Content-Length: ' . $size);
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Expires: 0');

				// Print the binary data
				echo $data;
				exit;				
			}
			else
			{
				print $data;
			}
		}
		else
		{
			print null;
		}
		
		mysqli_free_result($result_consult);
    }	
	
?>
