<?php
	
	include 'ConfigurationUserManagement.php';
 
	$id = $_GET["id"];

	if (ExistsStoryData($id) == true)
	{
		DownloadStory($id);
	}
	else
	{
		print "false";
	}

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	
	 //-------------------------------------------------------------
     //  DownloadStory
     //-------------------------------------------------------------
     function DownloadStory($id_par)
     {
		$query_consult = "SELECT * FROM bookdata WHERE id = $id_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::UserConsult::Select POIs failed");

		if ($row_data = mysqli_fetch_object($result_consult))
		{
			$data = $row_data->data;

			print $data;
		}
		else
		{
			print "";
		}
		
		mysqli_free_result($result_consult);
    }	
	
?>
