<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_POST["id"];
	
	$data_temporal = $_FILES["data"];
	$data = file_get_contents($data_temporal['tmp_name']);	
	
    // ++ LOGIN WITH email ++
	PublishStoryData($id, $data);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
 	 //  ExistsPublishedStory
     //-------------------------------------------------------------
	 function ExistsPublishedStory($id_par)
     {
		// Performing SQL Consult
		$query_data = "SELECT * FROM bookpublish WHERE id = $id_par";
		$result_data = mysqli_query($GLOBALS['LINK_DATABASE'],$query_data) or die("Query Error::ConfigurationUserManagement::ExistsStoryData");
		
		if ($row_data = mysqli_fetch_object($result_data))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }

     //-------------------------------------------------------------
     //  PublishStoryData
     //-------------------------------------------------------------
     function PublishStoryData($id_par, $data_par)
     {
		 if (ExistsPublishedStory($id_par) == false)
		 {
			$query_insert = "INSERT INTO bookpublish VALUES (?, ?)";
			$query_insert_data = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_data, 'is', $id_par, $data_par);
			if (!mysqli_stmt_execute($query_insert_data))
			{
				die("Query Error::PublishStory::Insert bookpublish Failed");
			}
		 }
		 else
		 {
			$query_string = "UPDATE bookpublish SET data = ? WHERE id = ?";
			$query_update_data = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_data, 'si', $data_par, $id_par);
			if (!mysqli_stmt_execute($query_update_data))
			{
				die("Query Error::PublishStory::Update bookpublish Failed");
			}
		 }
		 
		 print "true";
    }

?>
