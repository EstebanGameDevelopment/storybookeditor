<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_GET["id"];
	
    // ++ LOGIN WITH email ++
	DownloadStoryData($id);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     

     //-------------------------------------------------------------
     //  DownloadStoryData
     //-------------------------------------------------------------
     function DownloadStoryData($id_par)
     {
		$query_consult = "SELECT * FROM bookpublish WHERE id = $id_par";
		$result_consult = mysqli_query($GLOBALS['LINK_DATABASE'], $query_consult) or die("Query Error::DownloadStoryData::Download story $id_par failed");

		if ($row_data = mysqli_fetch_object($result_consult))
		{		 
			$data = $row_data->data;
			
			// Set headers to force download
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . "story.zip" . '"');
			header('Content-Length: ' . strlen($data));
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Expires: 0');

			// Print the binary data
			echo $data;
		} 
		else
		{
			print "false";	
		}		 		 
    }

?>
