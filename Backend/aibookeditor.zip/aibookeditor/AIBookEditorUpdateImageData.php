<?php
	
	include 'ConfigurationUserManagement.php';

	$data = $_POST["data"];

	$item_image = explode(';', $data);
	$number_images = count($item_image);

	$i = 0;
	for ($i = 0; $i < $number_images; $i++)			 
	{
		$tokens_image = explode(',', $item_image[$i]);		 
		UpdateImageData(intval($tokens_image[0]), $tokens_image[1], $tokens_image[2]);
	}
		 
	print "true";

	// Closing connection
	mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
 	 //  ExistsImageIndex
     //-------------------------------------------------------------
	 function ExistsImageIndex($id_par)
     {
		// Performing SQL Consult
		$query_story = "SELECT * FROM bookimages WHERE id = $id_par";
		$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::ExistsImageIndex = $id_par");
		
		if ($row_story = mysqli_fetch_object($result_story))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }
	 
     //-------------------------------------------------------------
     //  UpdateImageData
     //-------------------------------------------------------------
     function UpdateImageData($id_par, $name_par, $path_par)
     {		
		 if (ExistsImageIndex($id_par) == true)
		 {
			$query_string = "UPDATE bookimages SET name = ?, category = ? WHERE id = ?";
			$query_update_image = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_image, 'ssi', $name_par, $path_par, $id_par);
			if (!mysqli_stmt_execute($query_update_image))
			{
				die("Query Error::UpdateImageData::Update image properties bookimages Failed");
			}
		 }
    }

?>
