<?php
	
	include 'ConfigurationUserManagement.php';

	$data = $_POST["data"];

	$item_sound = explode(';', $data);
	$number_sounds = count($item_sound);

	$i = 0;
	for ($i = 0; $i < $number_sounds; $i++)			 
	{
		$tokens_sound = explode(',', $item_sound[$i]);		 
		UpdateSoundData(intval($tokens_sound[0]), $tokens_sound[1], $tokens_sound[2]);
	}
		 
	print "true";

	// Closing connection
	mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
 	 //  ExistsSoundIndex
     //-------------------------------------------------------------
	 function ExistsSoundIndex($id_par)
     {
		// Performing SQL Consult
		$query_story = "SELECT * FROM booksounds WHERE id = $id_par";
		$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::ExistsSoundIndex = $id_par");
		
		if ($row_story = mysqli_fetch_object($result_story))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }
	 
     //-------------------------------------------------------------
     //  UpdateSoundData
     //-------------------------------------------------------------
     function UpdateSoundData($id_par, $name_par, $path_par)
     {		
		 if (ExistsSoundIndex($id_par) == true)
		 {
			$query_string = "UPDATE booksounds SET name = ?, category = ? WHERE id = ?";
			$query_update_sound = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_sound, 'ssi', $name_par, $path_par, $id_par);
			if (!mysqli_stmt_execute($query_update_sound))
			{
				die("Query Error::UpdateSoundData::Update sound properties booksounds Failed");
			}
		 }
    }

?>
