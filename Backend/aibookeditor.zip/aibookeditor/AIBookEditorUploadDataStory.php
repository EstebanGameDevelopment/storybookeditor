<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_POST["id"];
	
	$data_temporal = $_FILES["data"];
	$data = file_get_contents($data_temporal['tmp_name']);	
	
    // ++ LOGIN WITH email ++
	UploadData($id, $data);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  UploadData
     //-------------------------------------------------------------
     function UploadData($id_par, $data_par)
     {
		 if (ExistsStoryData($id_par) == false)
		 {
			$query_insert = "INSERT INTO bookdata VALUES (?, ?)";
			$query_insert_data = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_data, 'is', $id_par, $data_par);
			if (!mysqli_stmt_execute($query_insert_data))
			{
				die("Query Error::UploadData::Insert bookdata Failed");
			}
		 }
		 else
		 {
			$query_string = "UPDATE bookdata SET data = ? WHERE id = ?";
			$query_update_data = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_data, 'si', $data_par, $id_par);
			if (!mysqli_stmt_execute($query_update_data))
			{
				die("Query Error::UploadData::Update bookdata Failed");
			}
		 }
		 
		 print "true";
    }

?>
