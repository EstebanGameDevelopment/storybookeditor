<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_POST["id"];
	$story = $_POST["story"];
	$name = $_POST["name"];
	$category = $_POST["category"];
	$size = $_POST["size"];
	
	$data_temporal = $_FILES["data"];
	$data_img = file_get_contents($data_temporal['tmp_name']);	

	UploadImageData($id, $story, $name, $category, $size, $data_img);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
 	 //  ExistsImageIndex
     //-------------------------------------------------------------
	 function ExistsImageIndex($id_par)
     {
		// Performing SQL Consult
		$query_story = "SELECT * FROM bookimages WHERE id = $id_par";
		$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::ExistsImageIndex = $id_par");
		
		if ($row_story = mysqli_fetch_object($result_story))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }
	 
     //-------------------------------------------------------------
     //  UploadImageData
     //-------------------------------------------------------------
     function UploadImageData($id_par, $story_par, $name_par, $category_par, $size_par, $data_image_par)
     {
		 $id_output = $id_par;
		 
		 // $data_par = mysqli_real_escape_string($GLOBALS['LINK_DATABASE'], $data_image_par);
		 $data_par = $data_image_par;
		 
		 if (ExistsImageIndex($id_par) == false)
		 {
			// New Data ID
			$query_maxdata = "SELECT max(id) as maximumId FROM bookimages";
			$result_maxdata = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxdata) or die("Query Error::UploadImageData::Select max bookimages failed");
			$row_maxdata = mysqli_fetch_object($result_maxdata);
			$dataid_output =  $row_maxdata->maximumId;
			if ($dataid_output == null) $dataid_output = 0;
			$dataid_output = $dataid_output + 1;
			$id_output = $dataid_output;
			mysqli_free_result($result_maxdata);

			$query_insert = "INSERT INTO bookimages VALUES (?, ?, ?, ?, ?, ?)";
			$query_insert_speech = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_speech, 'iissis', $dataid_output, $story_par, $name_par, $category_par, $size_par, $data_par);
			if (!mysqli_stmt_execute($query_insert_speech))
			{
				die("Query Error::UploadImageData::Insert bookindex Failed::$dataid_output, $story_par, $name_par, $category_par, $size_par, $data_par");
			}
		 }
		 else
		 {
			$query_string = "UPDATE bookimages SET data = ?, story = ?, name = ?, category = ?, size = ? WHERE id = ?";
			$query_update_image = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_image, 'sissii', $data_par, $story_par, $name_par, $category_par, $size_par, $id_par);
			if (!mysqli_stmt_execute($query_update_image))
			{
				die("Query Error::UploadImageData::Update bookimages Failed");
			}
		 }
		 
		 print "true" . $GLOBALS['PARAM_SEPARATOR'] . $id_output;
    }

?>
