<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_POST["id"];
	$user = $_POST["user"];
	$dataid = $_POST["dataid"];
	$title = $_POST["title"];
	$description = $_POST["description"];
	$category1 = $_POST["category1"];
	$category2 = $_POST["category2"];
	$category3 = $_POST["category3"];
	$timestamp = $_POST["time"];

	UploadStoryIndex($id, $user, $dataid, $title, $description, $category1, $category2, $category3, $timestamp);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  UploadStoryIndex
     //-------------------------------------------------------------
     function UploadStoryIndex($id_par, $user_par, $dataid_par, $title_par, $description_par, $category1_par, $category2_par, $category3_par, $timestamp_par)
     {
		 $id_output = $id_par;
		 $dataid_output = -1;
		 
		 if (ExistsStoryIndex($id_par) == false)
		 {
			if ($id_output < 0) $id_output = 0;
		
			// New Index ID
			$query_maxindex = "SELECT max(id) as maximumId FROM bookindex";
			$result_maxindex = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxindex) or die("Query Error::UploadStoryIndex::Select max bookindex failed");
			$row_maxindex = mysqli_fetch_object($result_maxindex);
			$id_output = $row_maxindex->maximumId;
			if ($id_output == null) $id_output = 0;
			$id_output = $id_output + 1;
			mysqli_free_result($result_maxindex);

			// New Data ID
			$query_maxdata = "SELECT max(id) as maximumId FROM bookindex";
			$result_maxdata = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxdata) or die("Query Error::UploadStoryIndex::Select max bookdata failed");
			$row_maxdata = mysqli_fetch_object($result_maxdata);
			$dataid_output =  $row_maxdata->maximumId;
			if ($dataid_output == null) $dataid_output = 0;
			$dataid_output = $dataid_output + 1;
			mysqli_free_result($result_maxdata);			

			$query_insert = "INSERT INTO bookindex VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$query_insert_story = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_story, 'iiissiiii', $id_output, $user_par, $dataid_output, $title_par, $description_par, $category1_par, $category2_par, $category3_par, $timestamp_par);
			if (!mysqli_stmt_execute($query_insert_story))
			{
				die("Query Error::UploadStoryIndex::Insert bookindex Failed::$id_output, $user_par, $dataid_output, $title_par, $description_par, $category1_par, $category2_par, $category3_par, $timestamp_par");
			}
		 }
		 else
		 {
			// Consult Data ID
			$query_story = "SELECT data FROM bookindex WHERE id = $id_par";
			$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::UploadStoryIndex::Exists Story Index");
			$dataid_output = $result_story->data;
					
			$query_string = "UPDATE bookindex SET $title = ?, $description = ?, $category1 = ?, $category2 = ?, $category3 = ?, $time = ? WHERE id = ?";
			$query_update_story = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_story, 'ssiiiii', $title_par, $description_par, $category1_par, $category2_par, $category3_par, $timestamp, $id_par);
			if (!mysqli_stmt_execute($query_update_story))
			{
				die("Query Error::UploadStoryIndex::Update bookindex Failed");
			}
		 }
		 
		 print "true" . $GLOBALS['PARAM_SEPARATOR'] . $id_output . $GLOBALS['PARAM_SEPARATOR'] . $dataid_output;
    }

?>
