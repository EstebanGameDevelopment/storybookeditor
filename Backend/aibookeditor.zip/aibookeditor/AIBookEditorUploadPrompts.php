<?php
	
	include 'ConfigurationUserManagement.php';
	
	$session = $_POST["session"];
	$mode = $_POST["mode"];
	$llm = $_POST["llm"];
	$command = $_POST["command"];	
	$data_temporal = $_FILES["data"];
	$data = file_get_contents($data_temporal['tmp_name']);	
	
	InsertPromptData($session, $mode, $llm, $command, $data);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  InsertPromptData
     //-------------------------------------------------------------
     function InsertPromptData($session_par, $mode_par, $llm_par, $command_par, $data_par)
     {
		// New Data ID
		$query_maxdata = "SELECT max(id) as maximumId FROM sessionprompts";
		$result_maxdata = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxdata) or die("Query Error::InsertPromptData::Select max sessionprompts failed");
		$row_maxdata = mysqli_fetch_object($result_maxdata);
		$dataid_output =  $row_maxdata->maximumId;
		if ($dataid_output == null) $dataid_output = 0;
		$dataid_output = $dataid_output + 1;
		$id_output = $dataid_output;
		mysqli_free_result($result_maxdata);		 
		 
		$query_insert = "INSERT INTO sessionprompts VALUES (?, ?, ?, ?, ?, ?)";
		$query_insert_data = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
		mysqli_stmt_bind_param($query_insert_data, 'isisss', $id_output, $session_par, $mode_par, $llm_par, $command_par, $data_par);
		if (!mysqli_stmt_execute($query_insert_data))
		{
			die("Query Error::InsertPromptData::Insert sessionprompts Failed::ID($id_output)::SESSION($session_par)");
		}
		
		print "true";
    }

?>
