<?php
	
	include 'ConfigurationUserManagement.php';

	$project = $_POST["project"];
	$id = $_POST["id"];
	$story = $_POST["story"];
	$name = $_POST["name"];
	$category = $_POST["category"];
	$extension = $_POST["extension"];
	$size = $_POST["size"];
	$userid = $_POST["userid"];
	$username = $_POST["username"];
	$password = $_POST["password"];	
	$voicename = $_POST["voicename"];	
	$language = $_POST["language"];	
				
	$data_temporal = $_FILES["data"];
	$data_sound = file_get_contents($data_temporal['tmp_name']);	
	
	if (strlen($voicename) > 1)
	{
		UploadVoice($project, $data_temporal, $userid, $username, $password, $voicename, $language);
	}

	UploadSoundData($id, $story, $name, $category, $extension, $size, $data_sound);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 function UploadVoice($project_par, $data_par, $userid_par, $username_par, $password_par, $voicename_par, $language_par)
	 {
		$urlSpeech = $GLOBALS['SPEECH_UPLOAD_ADDRESS'];
		
		// Initialize cURL
		$ch = curl_init();
		
		// Prepare file for upload
		$cfile = new CURLFile($data_par['tmp_name'], $data_par['type'], $data_par['name']);
		
		// Prepare post fields
		$dataSpeech = array(
			"project" => $project_par,
			"userid" => $userid_par,
			"username" => $username_par,
			"password" => $password_par,
			"voice" => $voicename_par,
			"language" => $language_par,			
			"file" => $cfile
		);
		
		// Set cURL options
		curl_setopt($ch, CURLOPT_URL, $urlSpeech);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $dataSpeech);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		// Execute the request
		$response = curl_exec($ch);
		
		// Check for errors
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		}
		
		// Close cURL session
		curl_close($ch);		 
	 }
	 
	 //-------------------------------------------------------------
 	 //  ExistsSoundIndex
     //-------------------------------------------------------------
	 function ExistsSoundIndex($id_par)
     {
		// Performing SQL Consult
		$query_story = "SELECT * FROM booksounds WHERE id = $id_par";
		$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::ExistsSoundIndex = $id_par");
		
		if ($row_story = mysqli_fetch_object($result_story))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }
	 
     //-------------------------------------------------------------
     //  UploadSoundData
     //-------------------------------------------------------------
     function UploadSoundData($id_par, $story_par, $name_par, $category_par, $extension_par, $size_par, $data_sound_par)
     {
		 $id_output = $id_par;
		 
		 // $data_final_sound = mysqli_real_escape_string($GLOBALS['LINK_DATABASE'], $data_sound_par);
		 $data_final_sound = $data_sound_par;
		 
		 if (ExistsSoundIndex($id_par) == false)
		 {
			// New Data ID
			$query_maxdata = "SELECT max(id) as maximumId FROM booksounds";
			$result_maxdata = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxdata) or die("Query Error::UploadSoundData::Select max booksounds failed");
			$row_maxdata = mysqli_fetch_object($result_maxdata);
			$dataid_output =  $row_maxdata->maximumId;
			if ($dataid_output == null) $dataid_output = 0;
			$dataid_output = $dataid_output + 1;
			$id_output = $dataid_output;
			mysqli_free_result($result_maxdata);

			$query_insert = "INSERT INTO booksounds VALUES (?, ?, ?, ?, ?, ?, ?)";
			$query_insert_sound = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_sound, 'iisssis', $dataid_output, $story_par, $name_par, $category_par, $extension_par, $size_par, $data_final_sound);
			if (!mysqli_stmt_execute($query_insert_sound))
			{
				die("Query Error::UploadSoundData::Insert booksounds Failed:: $dataid_output, $story_par, $name_par, $category_par, $extension_par, $size_par, " . strlen($data_final_sound));
			}
		 }
		 else
		 {
			$query_string = "UPDATE booksounds SET data = ?, story = ?, name = ?, category = ?, extension = ?, size = ? WHERE id = ?";
			$query_update_image = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_image, 'sissiiiii', $data_final_sound, $story_par, $name_par, $category_par, $extension_par, $size_par, $id_par);
			if (!mysqli_stmt_execute($query_update_image))
			{
				die("Query Error::UploadSoundData::Update booksounds Failed");
			}
		 }
		 
		 print "true" . $GLOBALS['PARAM_SEPARATOR'] . $id_output;
    }

?>
