<?php
	
	include 'ConfigurationUserManagement.php';

	$id = $_POST["id"];
	$story = $_POST["story"];
	$chapter = $_POST["chapter"];
	$page = $_POST["page"];
	$voice = $_POST["voice"];
	$instructions = $_POST["instructions"];
	$text = $_POST["text"];
	$userid = $_POST["userid"];
	$username = $_POST["username"];
	$password = $_POST["password"];
    $language = $_POST["language"];
    $speed = $_POST["speed"];
	$speed = $speed / 1000;

	$data_temporal = $_FILES["data"];
	$data_sound = file_get_contents($data_temporal['tmp_name']);	

	UploadSpeechData($id, $story, $chapter, $page, $voice, $instructions, $text, $data_sound);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
	 //-------------------------------------------------------------
 	 //  ExistsSpeechIndex
     //-------------------------------------------------------------
	 function ExistsSpeechIndex($id_par)
     {
		// Performing SQL Consult
		$query_story = "SELECT * FROM bookspeech WHERE id = $id_par";
		$result_story = mysqli_query($GLOBALS['LINK_DATABASE'],$query_story) or die("Query Error::ConfigurationUserManagement::ExistsStoryIndex");
		
		if ($row_story = mysqli_fetch_object($result_story))
		{
			return true;
		}
		else
		{
			return false;			
		}
	 }

     //-------------------------------------------------------------
     //  UploadSpeechData
     //-------------------------------------------------------------
     function UploadSpeechData($id_par, $story_par, $chapter_par, $page_par, $voice_par, $instructions_par, $text_par, $data_par)
     {
		 $id_output = $id_par;
		 
		 if (ExistsSpeechIndex($id_par) == false)
		 {
			// New Data ID
			$query_maxdata = "SELECT max(id) as maximumId FROM bookspeech";
			$result_maxdata = mysqli_query($GLOBALS['LINK_DATABASE'],$query_maxdata) or die("Query Error::UploadSpeechData::Select max bookspeech failed");
			$row_maxdata = mysqli_fetch_object($result_maxdata);
			$dataid_output =  $row_maxdata->maximumId;
			if ($dataid_output == null) $dataid_output = 0;
			$dataid_output = $dataid_output + 1;
			$id_output = $dataid_output;
			mysqli_free_result($result_maxdata);

			$query_insert = "INSERT INTO bookspeech VALUES (?, ?, ?, ?, ?)";
			$query_insert_speech = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_insert);
			mysqli_stmt_bind_param($query_insert_speech, 'iiiis', $dataid_output, $story_par, $chapter_par, $page_par, $data_par);
			if (!mysqli_stmt_execute($query_insert_speech))
			{
				die("Query Error::UploadSpeechData::Insert bookindex Failed::$dataid_output, $story_par, $chapter_par, $page_par, $data_par");
			}
		 }
		 else
		 {
			// Consult Data ID
			$query_string = "UPDATE bookspeech SET data = ?, story = ?, chapter = ?, page = ? WHERE id = ?";
			$query_update_speech = mysqli_prepare($GLOBALS['LINK_DATABASE'], $query_string);
			mysqli_stmt_bind_param($query_update_speech, 'siiii', $data_par, $story_par, $chapter_par, $page_par, $id_par);
			if (!mysqli_stmt_execute($query_update_speech))
			{
				die("Query Error::UploadSpeechData::Update bookspeech Failed");
			}
		 }
		 
		 print "true" . $GLOBALS['PARAM_SEPARATOR'] . $id_output;
    }

?>
