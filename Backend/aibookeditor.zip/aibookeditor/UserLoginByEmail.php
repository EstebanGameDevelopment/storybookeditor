<?php
	
	include 'ConfigurationUserManagement.php';
	
	$email = $_GET["email"];
	$password = $_GET["password"];

    // ++ LOGIN WITH email ++
	LoginEmail($email, $password);

    // Closing connection
    mysqli_close($GLOBALS['LINK_DATABASE']);
          
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
	 
     //-------------------------------------------------------------
     //  LoginEmail
     //-------------------------------------------------------------
     function LoginEmail($email_par, $password_par)
     {
		// Performing SQL Consult
		$query_user = "SELECT * FROM users WHERE email = '$email_par'";
		$result_user = mysqli_query($GLOBALS['LINK_DATABASE'],$query_user) or die("Query Error::UserLoginByEmail::Select users failed");
				
		if ($row_user = mysqli_fetch_object($result_user))
		{
			if (VerifyPassword($password_par, $row_user->password))
			{
				$id_user = $row_user->id;
				$name_user = $row_user->nickname;
				$registerdate_user = $row_user->registerdate;
				$lastlogin_user = $row_user->lastlogin;
				$admin_user = $row_user->admin;
				$code_user = $row_user->code;
				$validated_user = $row_user->validated;

				$current_time_login = GetCurrentTimestamp();
				
				// UPDATE ENERGY
				$query_update_user = "UPDATE users SET lastlogin=$current_time_login WHERE id = $id_user";
				$result_update_user = mysqli_query($GLOBALS['LINK_DATABASE'],$query_update_user) or die("Query Error::UserLoginByEmail::Update users failed");

				if ($result_update_user)
				{
					$output_total_login_data = "true" . $GLOBALS['USER_DATA_SEPARATOR'] .  $id_user . $GLOBALS['PARAM_SEPARATOR'] . $email_par . $GLOBALS['PARAM_SEPARATOR'] . $name_user . $GLOBALS['PARAM_SEPARATOR'] . $registerdate_user . $GLOBALS['PARAM_SEPARATOR'] . $lastlogin_user . $GLOBALS['PARAM_SEPARATOR'] . $admin_user . $GLOBALS['PARAM_SEPARATOR'] . $validated_user;
					$output_total_login_data = $output_total_login_data . GetUserProfileData($id_user);
					
					print $output_total_login_data;				
				}	
				else
				{
					print "false";
				}				
			}
			else
			{
				print "false";
			}				
		}
		else
		{
			print "false";
		}
	 
		// Free resultset
		mysqli_free_result($result_user);
    }

?>
